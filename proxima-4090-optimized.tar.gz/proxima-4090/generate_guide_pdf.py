#!/usr/bin/env python3
"""
generate_guide_pdf.py
Generates a professional 4-page PDF guide for deploying optimized ProxiChorizo on Ubuntu for RTX 4090.
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, HRFlowable
)
from reportlab.pdfgen import canvas

class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_header_footer(num_pages)
            super().showPage()
        super().save()

    def draw_header_footer(self, page_count):
        self.saveState()
        page_w, page_h = A4

        # Running Header (Pages 2+)
        if self._pageNumber > 1:
            self.setFont("Helvetica-Bold", 8)
            self.setFillColor(colors.HexColor("#334155"))
            self.drawString(40, page_h - 32, "PROXICHORIZO — RTX 4090 UBUNTU SETUP & OPTIMIZATION GUIDE")
            self.setFont("Helvetica", 8)
            self.setFillColor(colors.HexColor("#64748B"))
            self.drawRightString(page_w - 40, page_h - 32, "Proxima ECVRF Nonce Seeker")
            self.setStrokeColor(colors.HexColor("#CBD5E1"))
            self.setLineWidth(0.6)
            self.line(40, page_h - 36, page_w - 40, page_h - 36)

        # Running Footer (All pages)
        self.setStrokeColor(colors.HexColor("#E2E8F0"))
        self.setLineWidth(0.6)
        self.line(40, 40, page_w - 40, 40)

        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#64748B"))
        self.drawString(40, 28, "Optimized for NVIDIA GeForce RTX 4090 (Ada Lovelace, sm_89) • Suprnova Pool & Solo")
        page_str = f"Page {self._pageNumber} of {page_count}"
        self.drawRightString(page_w - 40, 28, page_str)

        self.restoreState()


def create_pdf(filename="/home/moideen/Downloads/proxima-4090/ProxiChorizo_RTX4090_Ubuntu_Setup_Guide.pdf"):
    doc = SimpleDocTemplate(
        filename,
        pagesize=A4,
        leftMargin=40,
        rightMargin=40,
        topMargin=44,
        bottomMargin=48
    )

    content = []
    styles = getSampleStyleSheet()

    # Brand Colors
    c_primary = colors.HexColor("#0F172A")    # Deep Navy
    c_accent = colors.HexColor("#0284C7")     # Ocean Blue
    c_dark = colors.HexColor("#1E293B")       # Slate
    c_text = colors.HexColor("#334155")       # Body Charcoal
    c_code_bg = colors.HexColor("#F8FAFC")    # Code background
    c_code_border = colors.HexColor("#CBD5E1")# Code border

    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=23,
        textColor=c_primary,
        spaceAfter=3
    )

    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        leading=13,
        textColor=c_accent,
        spaceAfter=10
    )

    h1_style = ParagraphStyle(
        'Heading1_Custom',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=15,
        textColor=c_primary,
        spaceBefore=10,
        spaceAfter=4,
        keepWithNext=True
    )

    h2_style = ParagraphStyle(
        'Heading2_Custom',
        parent=styles['Heading3'],
        fontName='Helvetica-Bold',
        fontSize=9.5,
        leading=12,
        textColor=c_accent,
        spaceBefore=6,
        spaceAfter=3,
        keepWithNext=True
    )

    body_style = ParagraphStyle(
        'Body_Custom',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=11.5,
        textColor=c_text,
        spaceAfter=4
    )

    code_style = ParagraphStyle(
        'Code_Custom',
        fontName='Courier',
        fontSize=7.8,
        leading=10.0,
        textColor=colors.HexColor("#0F172A")
    )

    note_style = ParagraphStyle(
        'Note_Custom',
        parent=body_style,
        fontName='Helvetica-Oblique',
        fontSize=8.0,
        leading=10.8,
        textColor=colors.HexColor("#1E3A8A")
    )

    def code_box(code_text):
        p = Paragraph(code_text.replace("\n", "<br/>").replace(" ", "&nbsp;"), code_style)
        t = Table([[p]], colWidths=[515])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), c_code_bg),
            ('BOX', (0, 0), (-1, -1), 0.6, c_code_border),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('LEFTPADDING', (0, 0), (-1, -1), 7),
            ('RIGHTPADDING', (0, 0), (-1, -1), 7),
        ]))
        return t

    def callout_box(text, title="IMPORTANT NOTE", border_color="#0284C7", bg_color="#F0F9FF"):
        p_title = Paragraph(f"<b>{title}</b>", ParagraphStyle('CallTitle', parent=body_style, fontName='Helvetica-Bold', fontSize=8.3, leading=10.5, textColor=colors.HexColor(border_color)))
        p_text = Paragraph(text, note_style)
        t = Table([[p_title], [p_text]], colWidths=[515])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor(bg_color)),
            ('BOX', (0, 0), (-1, -1), 0.8, colors.HexColor(border_color)),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('LEFTPADDING', (0, 0), (-1, -1), 7),
            ('RIGHTPADDING', (0, 0), (-1, -1), 7),
        ]))
        return t

    # =========================================================================
    # PAGE 1: Title, Architecture Spec, Steps 1 & 2
    # =========================================================================
    content.append(Paragraph("ProxiChorizo RTX 4090 Mining Guide", title_style))
    content.append(Paragraph("Step-by-Step Deployment, Compilation & Optimization Guide on Ubuntu Linux", subtitle_style))
    content.append(HRFlowable(width="100%", thickness=1.0, color=c_primary, spaceBefore=0, spaceAfter=6))

    overview_text = (
        "<b>Target GPU Architecture:</b> NVIDIA Ada Lovelace (AD102 / sm_89, 128 SMs, 16,384 CUDA Cores, 24 GB GDDR6X)<br/>"
        "<b>Expected Mining Hashrate:</b> ~48.5 – 51.0 MH/s @ 320–350 W power draw (~0.14 MH/s per Watt efficiency)<br/>"
        "<b>Workload Characteristic:</b> 100% integer ALU / wide-multiply carry-chain bound (Ed25519 ECVRF); 0% memory bottleneck.<br/>"
        "<b>Implemented Enhancements:</b> Native sm_89 comba profile (zero-overhead startup), skip redundant point decomp multiplication, 72 MB L2 table caching, 16,384 launch blocks."
    )
    content.append(callout_box(overview_text, title="DEPLOYMENT SPECIFICATION & PERFORMANCE TARGET", border_color="#0369A1", bg_color="#F0F9FF"))
    content.append(Spacer(1, 4))

    # Step 1
    content.append(Paragraph("1. Operating System & NVIDIA Driver Setup", h1_style))
    content.append(Paragraph(
        "Ubuntu 22.04 LTS or 24.04 LTS is recommended. The system requires an NVIDIA driver version 535 or newer (Driver 550+ recommended).",
        body_style
    ))
    content.append(code_box(
        "# 1. Verify RTX 4090 is detected on PCIe\n"
        "lspci | grep -i nvidia\n"
        "\n"
        "# 2. Install recommended NVIDIA proprietary driver (550+)\n"
        "sudo apt update && sudo apt install -y ubuntu-drivers-common\n"
        "sudo ubuntu-drivers install --gpgpu\n"
        "# (Alternative direct driver: sudo apt install -y nvidia-driver-550-server)\n"
        "\n"
        "# 3. Reboot system to initialize driver module\n"
        "sudo reboot"
    ))
    content.append(Spacer(1, 3))
    content.append(Paragraph("After rebooting, confirm driver initialization:", body_style))
    content.append(code_box("nvidia-smi"))
    content.append(Spacer(1, 4))

    # Step 2
    content.append(Paragraph("2. Install CUDA Toolkit & Build Essentials", h1_style))
    content.append(Paragraph(
        "ProxiChorizo requires CUDA 12.0+ (CUDA 12.4, 12.6, or 12.8 recommended) and standard C++17 build tools (`g++`, `make`).",
        body_style
    ))
    content.append(code_box(
        "# 1. Install standard build tools\n"
        "sudo apt update && sudo apt install -y build-essential git curl libssl-dev\n"
        "\n"
        "# 2. Add official NVIDIA CUDA repository keyring (Ubuntu 22.04)\n"
        "wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb\n"
        "sudo dpkg -i cuda-keyring_1.1-1_all.deb && sudo apt update\n"
        "\n"
        "# 3. Install CUDA Toolkit\n"
        "sudo apt install -y cuda-toolkit-12-6\n"
        "\n"
        "# 4. Add CUDA to shell PATH and library search path\n"
        "echo 'export PATH=/usr/local/cuda/bin:$PATH' >> ~/.bashrc\n"
        "echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> ~/.bashrc\n"
        "source ~/.bashrc\n"
        "\n"
        "# 5. Verify nvcc CUDA compiler\n"
        "nvcc --version"
    ))

    # =========================================================================
    # PAGE 2: Steps 3, 4, 5
    # =========================================================================
    content.append(PageBreak())

    # Step 3
    content.append(Paragraph("3. Transfer & Extract the Optimized Seeker", h1_style))
    content.append(Paragraph(
        "Transfer the pre-packaged <code>proxima-4090-optimized.tar.gz</code> archive to your target Ubuntu machine:",
        body_style
    ))
    content.append(code_box(
        "# From your host / workstation (replace with target IP and username):\n"
        "scp proxima-4090-optimized.tar.gz user@target-ip:~/\n"
        "\n"
        "# On the target Ubuntu machine, extract the archive:\n"
        "tar -xzvf ~/proxima-4090-optimized.tar.gz\n"
        "cd proxima-4090"
    ))
    content.append(Spacer(1, 4))

    # Step 4
    content.append(Paragraph("4. Compile Specifically for Ada Lovelace (sm_89)", h1_style))
    content.append(Paragraph(
        "Standard `make` compiles 7 architectures simultaneously. Use the custom <b><code>make ada</code></b> "
        "target to compile natively for compute_89 with PTX Level-3 optimization (`-Xptxas -O3`), completing in ~20 seconds.",
        body_style
    ))
    content.append(code_box(
        "# Compile native Ada Lovelace binary\n"
        "make ada\n"
        "\n"
        "# (Optional) Lean build (only comba & wNAF variants):\n"
        "# make ada-lean\n"
        "\n"
        "# Self-test mathematical correctness against Proxima node vectors\n"
        "./proxichorizo --selftest vectors.json\n"
        "./proxichorizo --fetest"
    ))
    content.append(Spacer(1, 3))
    content.append(callout_box(
        "Both self-tests must output <b>ok</b>. This verifies that point decompression and field arithmetic match the reference Go node.",
        title="VERIFICATION REQUIREMENT", border_color="#16A34A", bg_color="#F0FDF4"
    ))
    content.append(Spacer(1, 4))

    # Step 5
    content.append(Paragraph("5. GPU Clock Locking, Power Capping & Thermal Tuning", h1_style))
    content.append(Paragraph(
        "The RTX 4090 defaults to a 450 W limit. Because ProxiChorizo is 100% integer ALU-bound, running stock draws unnecessary power. "
        "Locking the core clock to 2,760 MHz and capping power to 340 W yields <b>>97% of maximum hashrate</b> while running cooler.",
        body_style
    ))

    tuning_data = [
        [Paragraph("<b>Parameter</b>", body_style), Paragraph("<b>Stock Setting</b>", body_style), Paragraph("<b>Optimized 4090 Setting</b>", body_style), Paragraph("<b>Purpose & Benefit</b>", body_style)],
        [Paragraph("Persistence Mode", body_style), Paragraph("Disabled (0)", body_style), Paragraph("<code>nvidia-smi -pm 1</code>", body_style), Paragraph("Prevents driver unload between kernel launches", body_style)],
        [Paragraph("Locked Core Clock", body_style), Paragraph("Dynamic (2.2-2.8 GHz)", body_style), Paragraph("<code>nvidia-smi -lgc 2760</code>", body_style), Paragraph("Locks SM at sweet spot; eliminates clock throttling", body_style)],
        [Paragraph("Power Limit", body_style), Paragraph("450 W", body_style), Paragraph("<code>nvidia-smi -pl 340</code>", body_style), Paragraph("Saves 110 W; runs cool at ~0.14 MH/s per Watt", body_style)],
        [Paragraph("Memory Clock", body_style), Paragraph("10,501 MHz", body_style), Paragraph("Stock or -500 MHz offset", body_style), Paragraph("Memory bandwidth idle (<1%); drops VRM temp", body_style)],
        [Paragraph("Thermal Guard", body_style), Paragraph("88°C", body_style), Paragraph("<code>--max-temp 82</code>", body_style), Paragraph("Auto-pauses only hot GPU until it cools 8°C", body_style)]
    ]
    t_tuning = Table(tuning_data, colWidths=[95, 105, 145, 170])
    t_tuning.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#E2E8F0")),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    content.append(t_tuning)
    content.append(Spacer(1, 4))

    content.append(code_box(
        "# Apply persistent clock & power limits (requires sudo):\n"
        "sudo nvidia-smi -pm 1\n"
        "sudo nvidia-smi -lgc 2760\n"
        "sudo nvidia-smi -pl 340"
    ))

    # =========================================================================
    # PAGE 3: Step 6 (Pool & Solo Mining) + Flag Reference Table
    # =========================================================================
    content.append(PageBreak())

    content.append(Paragraph("6. Launching the Seeker (Pool & Solo Mining)", h1_style))
    content.append(Paragraph("<b>A. Pool Mining (Suprnova Pool)</b>", h2_style))
    content.append(Paragraph(
        "Register at <b>https://proxi.suprnova.cc</b>, obtain your seeker token, and place the pool's <code>proxima.key</code> next to the binary:",
        body_style
    ))
    content.append(code_box(
        "./proxichorizo \\\n"
        "  --proxi http://proxi.suprnova.cc:8100 \\\n"
        "  --token YOUR_SEEKER_TOKEN \\\n"
        "  --key-file proxima.key \\\n"
        "  --variant fe32c_wnaf_s16_c \\\n"
        "  --blocks 16384 \\\n"
        "  --threads 256 \\\n"
        "  --iters 1 \\\n"
        "  --max-temp 82 \\\n"
        "  --api-bind 127.0.0.1:4078 \\\n"
        "  --name rig_4090"
    ))
    content.append(Spacer(1, 4))

    content.append(Paragraph("<b>B. Solo Mining with Local Proxima Node</b>", h2_style))
    content.append(Paragraph(
        "Solo mining connects to your local node running <code>proxi node mine</code> on port 8200:",
        body_style
    ))
    content.append(code_box(
        "./proxichorizo \\\n"
        "  --proxi http://127.0.0.1:8200 \\\n"
        "  --token YOUR_SEEKER_TOKEN \\\n"
        "  --key-file proxima.key \\\n"
        "  --variant fe32c_wnaf_s16_c \\\n"
        "  --blocks 16384 \\\n"
        "  --threads 256 \\\n"
        "  --iters 1"
    ))
    content.append(Spacer(1, 6))

    # Command line flags table
    content.append(Paragraph("<b>ProxiChorizo Command-Line Flag Reference for RTX 4090:</b>", body_style))
    flag_data = [
        [Paragraph("<b>Option Flag</b>", body_style), Paragraph("<b>RTX 4090 Setting</b>", body_style), Paragraph("<b>Technical Explanation & Optimization Rationale</b>", body_style)],
        [Paragraph("<code>--variant</code>", body_style), Paragraph("<code>fe32c_wnaf_s16_c</code>", body_style), Paragraph("Product-scanning (comba) 8x32 wide-multiply arithmetic with width-5 wNAF, split 16-point Montgomery inversion, and cofactor folded into the scalar.", body_style)],
        [Paragraph("<code>--blocks</code>", body_style), Paragraph("<code>16384</code>", body_style), Paragraph("Launches 128 blocks per SM across all 128 SMs of the RTX 4090 ($128 \\times 128 = 16,384$), maximizing grid saturation and hiding retry queue latency.", body_style)],
        [Paragraph("<code>--threads</code>", body_style), Paragraph("<code>256</code>", body_style), Paragraph("256 threads per block @ 2 blocks per SM = 512 threads per SM (16 warps). Caps registers at 128 with zero local memory register spilling.", body_style)],
        [Paragraph("<code>--iters</code>", body_style), Paragraph("<code>1</code>", body_style), Paragraph("1 nonce per thread per launch. Amortizes pass overhead across the grid better than thread looping.", body_style)],
        [Paragraph("<code>--max-temp</code>", body_style), Paragraph("<code>82</code>", body_style), Paragraph("Per-GPU core temperature guard in °C. If the GPU reaches 82°C, it pauses alone and resumes when cooled 8°C below the threshold.", body_style)],
        [Paragraph("<code>--api-bind</code>", body_style), Paragraph("<code>127.0.0.1:4078</code>", body_style), Paragraph("Enables local JSON stats API at <code>/</code> and mmpOS/HiveOS-compatible line format at <code>/mmpos</code>.", body_style)],
        [Paragraph("<code>-d</code>", body_style), Paragraph("<code>0</code> (or <code>0,1</code>)", body_style), Paragraph("PCI bus GPU selection. Omit to run across all detected GPUs in a single process.", body_style)],
    ]
    t_flags = Table(flag_data, colWidths=[85, 115, 315])
    t_flags.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#E2E8F0")),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    content.append(t_flags)

    # =========================================================================
    # PAGE 4: Step 7 (systemd 24/7 service), Step 8 (Benchmarks & Troubleshooting)
    # =========================================================================
    content.append(PageBreak())

    content.append(Paragraph("7. Running 24/7 Background Mining with systemd", h1_style))
    content.append(Paragraph(
        "To ensure continuous mining with automatic start on boot and automatic crash recovery, install a systemd service unit:",
        body_style
    ))
    user_name = "ubuntu"
    content.append(code_box(
        "# 1. Create the systemd service file\n"
        "sudo nano /etc/systemd/system/proxichorizo.service\n"
        "\n"
        "# 2. Paste the following configuration:\n"
        "[Unit]\n"
        "Description=ProxiChorizo RTX 4090 Seeker\n"
        "After=network-online.target\n"
        "\n"
        "[Service]\n"
        "Type=simple\n"
        "User=" + user_name + "\n"
        "WorkingDirectory=/home/" + user_name + "/proxima-4090\n"
        "ExecStartPre=/usr/bin/nvidia-smi -pm 1\n"
        "ExecStartPre=/usr/bin/nvidia-smi -lgc 2760\n"
        "ExecStartPre=/usr/bin/nvidia-smi -pl 340\n"
        "ExecStart=/home/" + user_name + "/proxima-4090/proxichorizo \\\n"
        "  --proxi http://proxi.suprnova.cc:8100 \\\n"
        "  --token YOUR_POOL_TOKEN \\\n"
        "  --key-file /home/" + user_name + "/proxima-4090/proxima.key \\\n"
        "  --variant fe32c_wnaf_s16_c --blocks 16384 --threads 256 --iters 1 --max-temp 82\n"
        "Restart=always\n"
        "RestartSec=5\n"
        "\n"
        "[Install]\n"
        "WantedBy=multi-user.target\n"
        "\n"
        "# 3. Reload systemd, enable and start the service:\n"
        "sudo systemctl daemon-reload && sudo systemctl enable --now proxichorizo\n"
        "\n"
        "# 4. Check status and view live output:\n"
        "sudo systemctl status proxichorizo\n"
        "journalctl -u proxichorizo -f"
    ))
    content.append(Spacer(1, 4))

    # Step 8
    content.append(Paragraph("8. Benchmark Comparisons & Operational Troubleshooting", h1_style))
    bench_data = [
        [Paragraph("<b>GPU Model</b>", body_style), Paragraph("<b>Compute Architecture</b>", body_style), Paragraph("<b>Power Cap</b>", body_style), Paragraph("<b>Expected Hashrate</b>", body_style), Paragraph("<b>Efficiency (MH/s / W)</b>", body_style)],
        [Paragraph("RTX 3070", body_style), Paragraph("sm_86 (46 SMs)", body_style), Paragraph("240 W", body_style), Paragraph("11.5 MH/s", body_style), Paragraph("0.048", body_style)],
        [Paragraph("CMP 170HX", body_style), Paragraph("sm_80 (74 SMs)", body_style), Paragraph("200 W", body_style), Paragraph("13.3 MH/s", body_style), Paragraph("0.067", body_style)],
        [Paragraph("RTX 5080", body_style), Paragraph("sm_120 (84 SMs)", body_style), Paragraph("340 W", body_style), Paragraph("33.0 MH/s", body_style), Paragraph("0.097", body_style)],
        [Paragraph("<b>RTX 4090 (Optimized)</b>", body_style), Paragraph("<b>sm_89 (128 SMs)</b>", body_style), Paragraph("<b>340 W</b>", body_style), Paragraph("<b>48.5 – 51.0 MH/s</b>", body_style), Paragraph("<b>0.144 – 0.148</b>", body_style)],
        [Paragraph("RTX 5090", body_style), Paragraph("sm_120 (170 SMs)", body_style), Paragraph("600 W", body_style), Paragraph("64.0 MH/s", body_style), Paragraph("0.107", body_style)],
    ]
    t_bench = Table(bench_data, colWidths=[120, 110, 85, 110, 90])
    t_bench.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#E2E8F0")),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('BACKGROUND', (0, 4), (-1, 4), colors.HexColor("#FEF3C7")), # Highlight 4090
    ]))
    content.append(t_bench)
    content.append(Spacer(1, 4))

    troubleshoot_text = (
        "<b>Key Troubleshooting Items:</b><br/>"
        "• <b>`CUDA error 2 (out of memory)`:</b> Verify `--blocks 16384` is specified. Sizing allocates ~848 MB VRAM for scratch buffers (well within the 24 GB capacity).<br/>"
        "• <b>`Thermal pause triggered (yellow console line)`:</b> The GPU exceeded `--max-temp` (default 88°C, set to 82°C above). Lower power cap to 320 W (`sudo nvidia-smi -pl 320`) or increase fan profile.<br/>"
        "• <b>`Share rejected (422)`:</b> Check pool token in command line or verify system clock is synchronized (`sudo timedatectl set-ntp on`).<br/>"
        "• <b>`Stale share (409)`:</b> Pool slot shifted before share arrived. Use wired Ethernet to minimize network round-trip latency to the pool server."
    )
    content.append(callout_box(troubleshoot_text, title="OPERATIONAL TROUBLESHOOTING CHEAT-SHEET", border_color="#B45309", bg_color="#FFFBEB"))

    # Build PDF
    doc.build(content, canvasmaker=NumberedCanvas)
    print(f"Successfully generated clean 4-page PDF: {filename}")

if __name__ == "__main__":
    create_pdf()
